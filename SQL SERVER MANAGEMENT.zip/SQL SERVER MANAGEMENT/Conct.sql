SELECT TOP (1000) [BusinessEntityID]
     
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Full Name] = [FirstName] + ' ' + [LastName]
  FROM [AdventureWorks2019].[Person].[Person]

 