SELECT 
	B.FirstName,
	B.LastName,
	B.PersonType,
	
	C.[Group],
      A.[TerritoryID]
      ,A.[SalesQuota]
      ,A.[Bonus]
      ,A.[CommissionPct]
      ,A.[SalesYTD]
      ,A.[SalesLastYear]
   
  FROM [AdventureWorks2019].[Sales].[SalesPerson] A
 INNER JOIN [AdventureWorks2019].[Person].[Person] B 
  ON A.BusinessEntityID = B.BusinessEntityID
 INNER JOIN [AdventureWorks2019].[Sales].[SalesTerritory] C
  ON A.TerritoryID = C.TerritoryID

  WHERE C.[Group] = 'Europe'