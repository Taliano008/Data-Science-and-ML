/*SELECT
[Employee] = COUNT(*),
[JobTitle],
[VacationTime] = SUM([VacationHours])

FROM [AdventureWorks2019].[HumanResources].[Employee]

GROUP BY 
[JobTitle],
[Gender] */
SELECT DISTINCT
[JobTitle],
[Gender]
FROM [AdventureWorks2019].[HumanResources].[Employee]










