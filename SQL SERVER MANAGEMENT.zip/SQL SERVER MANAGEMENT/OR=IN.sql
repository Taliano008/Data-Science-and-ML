SELECT TOP (1000) [BusinessEntityID]
      ,[NationalIDNumber]
      ,[LoginID]
      ,[OrganizationNode]
      ,[OrganizationLevel]
      ,[JobTitle]
      ,[BirthDate]
      ,[MaritalStatus]
      ,[Gender]
      ,[HireDate]
      ,[SalariedFlag]
      ,[VacationHours]
      ,[SickLeaveHours]
      ,[CurrentFlag]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2019].[HumanResources].[Employee]
  /*WHERE [JobTitle] = 'Sales Representative' AND 
  [MaritalStatus] = 's'
   WHERE [JobTitle] = 'Sales Representative' OR 
  [MaritalStatus] = 's'
  WHERE [JobTitle] = 'Sales Representative' OR 
  [JobTitle] ='Accounts Receivable Specialist' OR
  [JobTitle] ='Senior Design Engineer'
  */
  -- A simple way to select multiple rows
  WHERE [JobTitle] IN ('Sales Representative','Accounts Receivable Specialist''Senior Design Engineer')