 SELECT TOP (1000) [Commission YTD] = [SalesYTD] * [CommissionPct]
		,[Income YTD] = [SalesYTD] * [CommissionPct] + [Bonus]
		,[Difference] = [SalesYTD] - [SalesLastYear]
		,[Bonus Fairness] = ([Bonus]/[SalesYTD]) * 100 
      ,[TerritoryID]
      ,[SalesQuota]
      ,[Bonus]
      ,[CommissionPct]
      ,[SalesYTD]
      ,[SalesLastYear]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2019].[Sales].[SalesPerson]

  ORDER BY [Difference] DESC
