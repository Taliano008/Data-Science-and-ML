SELECT TOP (1000) [BusinessEntityID]
      ,[PhoneNumber]
	  ,[Area Code] = LEFT([PhoneNumber], 3)
	  ,[Phone n.o length] = LEN([PhoneNumber])
     
  FROM [AdventureWorks2019].[Person].[PersonPhone]

  --WHERE [PhoneNumber] NOT LIKE '%(%'
  WHERE LEN([PhoneNumber]) =19