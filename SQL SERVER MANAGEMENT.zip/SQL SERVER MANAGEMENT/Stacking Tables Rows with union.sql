SELECT--[OrderID] =  [SalesOrderID]
   --  ,[Order Type] = 'Customer Order'
      [OrderDate]
	 -- ,TotalDue
  FROM [AdventureWorks2019].[Sales].[SalesOrderHeader]

  WHERE YEAR([OrderDate]) = 2013

  UNION ALL  --UNION ALL you to select all data even it is not UNiQUE

  SELECT --[PurchaseOrderID]
  --	   ,[Order Type] = 'Vendor Order'

      [OrderDate]

    --  ,TotalDue
  FROM [AdventureWorks2019].[Purchasing].[PurchaseOrderHeader]
  WHERE YEAR([OrderDate]) = 2013