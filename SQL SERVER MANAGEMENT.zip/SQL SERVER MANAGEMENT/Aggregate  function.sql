--SELECT COUNT(*) FROM [Sales].[SalesOrderHeader]

--SELECT COUNT([SalesOrderID]) FROM [Sales].[SalesOrderHeader]
--SELECT COUNT([CurrencyRateID]) FROM [Sales].[SalesOrderHeader]
--SELECT SUM (TotalDue) FROM [Sales].[SalesOrderHeader]
--WHERE [OnlineOrderFlag] = 1

SELECT MAX (TotalDue) FROM [Sales].[SalesOrderHeader]

