SELECT [LastName],
COUNT(*)

FROM [AdventureWorks2019].[Person].Person 

GROUP BY [LastName]

HAVING COUNT(*) >1

SELECT 
COUNT(*)
FROM [AdventureWorks2019].[Person].Person 
WHERE [LastName] = 'Adams'
