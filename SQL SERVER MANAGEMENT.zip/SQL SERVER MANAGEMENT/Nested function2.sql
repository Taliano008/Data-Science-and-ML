SELECT TOP (1000)
     [NationalIDNumber]
	 ,[Length] = LEN(NationalIDNumber)
	 ,[Padded ID] = RIGHT('0000000000'+ [NationalIDNumber],10 ) -- Nested fuction 
      
  FROM [AdventureWorks2019].[HumanResources].[Employee]

  ORDER BY [Length] ASCp;''0