SELECT   GETDATE() - 4000
SELECT
      [OrderDate] 
  FROM [AdventureWorks2019].[Sales].[SalesOrderHeader]
  WHERE [OrderDate] >=CAST(GETDATE() - 4000 AS DATE)
  ORDER BY 1
