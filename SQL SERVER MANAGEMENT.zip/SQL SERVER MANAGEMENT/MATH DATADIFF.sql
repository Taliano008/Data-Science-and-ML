SELECT [OrderDate],
[ShipDate],
[Elapsed Days] = DATEDIFF(DAY, [OrderDate],[ShipDate])

FROM [AdventureWorks2019].[Sales].[SalesOrderHeader]