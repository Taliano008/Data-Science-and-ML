SELECT 
[Organization level] = [OrganizationLevel],
[JobTitle],
[HireDate],
[VacationHours]

FROM [AdventureWorks2019].[HumanResources].[Employee]