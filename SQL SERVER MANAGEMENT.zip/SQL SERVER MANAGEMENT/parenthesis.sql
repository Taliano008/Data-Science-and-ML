SELECT TOP (1000) [BusinessEntityID]
      ,[NationalIDNumber]
      ,[LoginID]
      ,[OrganizationNode]
      ,[OrganizationLevel]
      ,[JobTitle]
      ,[BirthDate]
      ,[MaritalStatus]
      ,[Gender]
      ,[HireDate]
      ,[SalariedFlag]
      ,[VacationHours]
      ,[SickLeaveHours]
      ,[CurrentFlag]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2019].[HumanResources].[Employee]

  --Always use parenthesis

  WHERE [OrganizationLevel] = 4
  AND( [SalariedFlag] = 1
  OR [JobTitle] = 'Senior tool Designer')
  /* we want 
  Organization level  = 4
AND 
Salaried Flag = 1 OR = 'Senior text Designer'
*/