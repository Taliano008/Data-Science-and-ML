SELECT TOP (1000) 
      [TotalDue]
	  ,[Trancated Due] = CAST([TotalDue] AS INT)
      
  FROM [AdventureWorks2019].[Sales].[SalesOrderHeader]
