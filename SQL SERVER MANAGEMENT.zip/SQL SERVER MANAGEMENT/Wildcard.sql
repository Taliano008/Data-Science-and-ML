SELECT [BusinessEntityID]
      ,[PersonType]
      ,[NameStyle]
      ,[Title]
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Suffix]
      ,[EmailPromotion]
      ,[AdditionalContactInfo]
      ,[Demographics]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [AdventureWorks2019].[Person].[Person]
  /*WHERE [FirstName] = 'Tommy'
  AND [LastName] = 'Black

  WHERE [FirstName] LIKE 'Tom%'
  AND [LastName] LIKE 'B%'  
  '*/


  WHERE [FirstName] LIKE '[abc]%'