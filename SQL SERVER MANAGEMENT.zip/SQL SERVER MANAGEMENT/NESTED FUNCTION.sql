SELECT TOP (1000) [BusinessEntityID]
  
      ,[EmailAddress]
	  ,[Length] = LEN([EmailAddress]) - 20,
	  [Username] = LEFT([EmailAddress],LEN([EmailAddress]) - 20)   --LEn Has been used as an innerfunction  
    
  FROM [AdventureWorks2019].[Person].[EmailAddress]
