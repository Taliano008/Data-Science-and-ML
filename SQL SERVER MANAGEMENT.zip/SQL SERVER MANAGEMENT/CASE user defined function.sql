SELECT DISTINCT
      [JobTitle],
	  [JOB CATEGORY] = 
	  CASE
	  WHEN [JobTitle] LIKE '%President%' THEN 'President'
	  WHEN [JobTitle] LIKE '%Production%' THEN 'Production'
	   WHEN [JobTitle] LIKE '%Manager%' THEN 'Manager'
	    
	  ELSE 'Other'
	  END
      
  FROM [AdventureWorks2019].[HumanResources].[Employee]
