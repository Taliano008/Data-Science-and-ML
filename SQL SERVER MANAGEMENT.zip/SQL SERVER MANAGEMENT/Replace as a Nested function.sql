SELECT TOP (1000) [ProductDescriptionID]
      ,[Description]
	  ,[Cleaned Description]  = REPLACE(REPLACE([Description], ',',' '), '.', ' ')
  FROM [AdventureWorks2019].[Production].[ProductDescription]
