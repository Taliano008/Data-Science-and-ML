SELECT  [SalesOrderID]
     ,[OrderDate]    
  
      ,[Total Amount Due] = [TotalDue]
   
  FROM [AdventureWorks2019].[Sales].[SalesOrderHeader]

  WHERE [TotalDue] > 10000
  ORDER BY 3 DESC  -- executed last ASC