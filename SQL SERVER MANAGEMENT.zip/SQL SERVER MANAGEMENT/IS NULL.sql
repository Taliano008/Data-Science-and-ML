SELECT 
      [Title]
	  ,[Modified Title] = ISNULL([Title], 'No Title')
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      
  FROM [AdventureWorks2019].[Person].[Person]
