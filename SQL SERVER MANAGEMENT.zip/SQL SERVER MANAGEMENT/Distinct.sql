SELECT DISTINCT
[JobTitle]

From [AdventureWorks2019].[HumanResources].Employee
ORDER BY [JobTitle]